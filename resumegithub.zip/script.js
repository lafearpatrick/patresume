
/* ============================= */
/* MOBILE NAVIGATION TOGGLE */
/* ============================= */

function toggleMenu(){

document.querySelector(".nav-links").classList.toggle("active");

}


/* ============================= */
/* SCROLL REVEAL ANIMATION */
/* ============================= */

const observer = new IntersectionObserver(entries => {

entries.forEach(entry => {

if(entry.isIntersecting){

entry.target.classList.add("show");

}

});

});


document.querySelectorAll(".hidden").forEach(el => {

observer.observe(el);

});


/* ============================= */
/* TYPING ANIMATION */
/* ============================= */

const textArray = [

"Aspiring Data Analyst",

"Python | SQL | Excel",

"Data Visualization Specialist",

"Seeking Internship & Full-Time Opportunities"

];

let typingElement = document.getElementById("typing");

let textIndex = 0;

let charIndex = 0;

let isDeleting = false;


function typeAnimation(){

let currentText = textArray[textIndex];

if(isDeleting){

typingElement.textContent = currentText.substring(0, charIndex--);

}
else{

typingElement.textContent = currentText.substring(0, charIndex++);

}

if(!isDeleting && charIndex === currentText.length){

isDeleting = true;

setTimeout(typeAnimation, 1500);

return;

}

if(isDeleting && charIndex === 0){

isDeleting = false;

textIndex = (textIndex + 1) % textArray.length;

}

setTimeout(typeAnimation, isDeleting ? 50 : 100);

}

typeAnimation();


/* ============================= */
/* NAVBAR BACKGROUND ON SCROLL */
/* ============================= */

window.addEventListener("scroll", function(){

const navbar = document.querySelector(".navbar");

if(window.scrollY > 50){

navbar.style.background = "rgba(2,6,23,0.95)";

}
else{

navbar.style.background = "rgba(2,6,23,0.8)";

}

});


/* ============================= */
/* SMOOTH FADE-IN ON PAGE LOAD */
/* ============================= */

window.addEventListener("load", function(){

document.body.style.opacity = "1";

});

